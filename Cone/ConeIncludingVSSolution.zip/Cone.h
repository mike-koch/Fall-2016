/*
 *  Name: Mike Koch
 *  Project: 1 - Drawing a Cone
 */

#ifndef CONE
#define CONE

float* generateCone(float baseRadius, float height, float topRadius, int numberOfSteps, int& numberOfValues);
#endif